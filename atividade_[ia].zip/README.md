# Atividade IA - Iris (UCI)

Arquivos:
- IA_Atividade_Iris.ipynb : Notebook com resolução completa.
- iris_full.csv : Dataset usado (exportado do sklearn.datasets)
- metrics_summary.csv : Métricas resumidas dos modelos

Como rodar:
1. Abrir o notebook `IA_Atividade_Iris.ipynb` em JupyterLab/Jupyter Notebook.
2. Executar todas as células (o notebook carrega o dataset diretamente do scikit-learn).

Commits sugeridos (exemplos):
- feat: adicionar notebook inicial com exploração de dados
- feat: implementar DecisionTree, KNN e LogisticRegression
- docs: adicionar README e salvar métricas
- chore: ajuste final e formatação para entrega
